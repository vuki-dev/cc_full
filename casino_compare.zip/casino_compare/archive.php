<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package casino_compare
 */

get_header();
?>

	<main id="primary" class="site-main main-bg">
		<div class="container">


		
		
		</div> <!-- container end -->
	</main><!-- #main -->


<?php 
get_footer();
?>