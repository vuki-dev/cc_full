<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package casino_compare
 */

?> 

	<footer id="colophon" class="site-footer <?php if(is_page('slots')){
		echo 'main-bg';
	}
	?>">
		<div class="container">
			<div class="footer-container">
				<div class="footer-top">
					<div class="site-info">
						<div class="footer-logo">
							<?php 
								$footer_logo = get_field('footer_logo','option');	
							?>
							<?php if($footer_logo) : 							
								$footer_logo_img = $footer_logo['url'];
								$footer_logo_alt = $footer_logo['alt'];
							?>
	
								<img src="<?php echo $footer_logo_img ?>" alt="<?php echo $footer_logo_alt ?>">
	
							<?php endif; ?>
							
						</div>
						<div class="footer-text">
							<?php 
							$footer_text = get_field('footer_text','option');
							
							if($footer_text) {
								echo $footer_text;
							}
							?>
						</div>
					</div><!-- .site-info -->
					<nav>
						<h3>Information</h3>
						<?php 
							wp_nav_menu(array(
								'theme-location' => 'footer-menu'
							))
						?>
	
					</nav>
				</div>
				<div class="footer-bottom">
					<div class="copyrights">
						<?php 
						$copyright = get_field('copyright_text','option');
	
						if($copyright) :
						?>
							<p class="copyright-text">
								<?php echo $copyright ?>
							</p> 
						<?php endif; ?>
						
						<span class="copy-span">&copy; - zvecancasino.zv</span>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- #colophon -->
	
	<div class="compare-sticky-div">
		<div class="container">
			<div class="sticky-title">   
				<h4>Casino Compare</h4>
				<span class="sticky-title-span"></span>
			</div>
			<div class="sticky-slots">
				
				<div class="compare-slot">
					<div class="slot-img">
						<img src="" alt="">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 10.8334H10.8334V15.8334H9.16675V10.8334H4.16675V9.16675H9.16675V4.16675H10.8334V9.16675H15.8334V10.8334Z" fill="white"/>
						</svg>
					</div>
					<div class="remove-slot">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 5.34175L14.6584 4.16675L10.0001 8.82508L5.34175 4.16675L4.16675 5.34175L8.82508 10.0001L4.16675 14.6584L5.34175 15.8334L10.0001 11.1751L14.6584 15.8334L15.8334 14.6584L11.1751 10.0001L15.8334 5.34175Z" fill="white"/>
						</svg>
					</div>
				</div>
				
				<div class="compare-slot">
					<div class="slot-img">
						<img src="" alt="">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 10.8334H10.8334V15.8334H9.16675V10.8334H4.16675V9.16675H9.16675V4.16675H10.8334V9.16675H15.8334V10.8334Z" fill="white"/>
						</svg>
					</div>
					<div class="remove-slot">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 5.34175L14.6584 4.16675L10.0001 8.82508L5.34175 4.16675L4.16675 5.34175L8.82508 10.0001L4.16675 14.6584L5.34175 15.8334L10.0001 11.1751L14.6584 15.8334L15.8334 14.6584L11.1751 10.0001L15.8334 5.34175Z" fill="white"/>
						</svg>
					</div>
				</div>
				
				<div class="compare-slot">
					<div class="slot-img">
						<img src="" alt="">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 10.8334H10.8334V15.8334H9.16675V10.8334H4.16675V9.16675H9.16675V4.16675H10.8334V9.16675H15.8334V10.8334Z" fill="white"/>
						</svg>
					</div>
					<div class="remove-slot">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 5.34175L14.6584 4.16675L10.0001 8.82508L5.34175 4.16675L4.16675 5.34175L8.82508 10.0001L4.16675 14.6584L5.34175 15.8334L10.0001 11.1751L14.6584 15.8334L15.8334 14.6584L11.1751 10.0001L15.8334 5.34175Z" fill="white"/>
						</svg>
					</div>
				</div>
				
				<div class="compare-slot">
					<div class="slot-img">
						<img src="" alt="">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 10.8334H10.8334V15.8334H9.16675V10.8334H4.16675V9.16675H9.16675V4.16675H10.8334V9.16675H15.8334V10.8334Z" fill="white"/>
						</svg>
					</div>
					<div class="remove-slot">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M15.8334 5.34175L14.6584 4.16675L10.0001 8.82508L5.34175 4.16675L4.16675 5.34175L8.82508 10.0001L4.16675 14.6584L5.34175 15.8334L10.0001 11.1751L14.6584 15.8334L15.8334 14.6584L11.1751 10.0001L15.8334 5.34175Z" fill="white"/>
						</svg>
					</div>
				</div>
				

			</div>
			<div class="sticky-buttons">
				<div>
					<button class="compare-btn">COMPARE NOW</button> 
				</div>
				<div>
					<button class="close-btn">CLOSE</button>
				</div>
			</div>
		</div>
	</div> 

</div><!-- #page -->


<?php wp_footer(); ?>

</body>
</html>
