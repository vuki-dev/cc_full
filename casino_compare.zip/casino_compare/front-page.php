<?php 

    get_header();

?>

    <main class="frontpage-main">
        <?php 
            $hero_img = get_field('hero_image','option');
            $hero_bg_color = get_field('hero_bg_color','option');
        ?>
        <section class="hero-section" style="background-image: url(<?php echo $hero_img['url'] ?>); background-color:<?php echo $hero_bg_color?> ;" >
            <div class="container">
                <div class="hero-content">
                    <div class="hero-title">
                        <?php if(get_bloginfo('name')) :?>
                        <h1><?php echo get_bloginfo('name'); ?></h1>
                        <?php endif; ?>
                    </div>
                    <div class="hero-tagline">
                        <?php if(get_field('hero_tagline','option')) :?>
                        <p><?php echo get_field('hero_tagline','option') ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="hero-search">
                        <form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>">
                            <input type="text" name="s" id="s1" placeholder="Search CasinoCompare" class="search-input">
                        </form>
                    </div>
                </div>
            </div>        
        </section>

        <section class="categories">
            <div class="container">
                <h2>What Are You Looking For?</h2>
                <div class="cards">
                    <?php if( have_rows('cards_repeater')) :?>
                        <?php 
                            while(have_rows('cards_repeater')) : the_row();
                            $card_title = get_sub_field('card_title');
                            $card_img = get_sub_field('card_img');
                            $dataset = get_sub_field('dataset')
                        ?>  
                            
                        <article class="single-card" data-inf="<?php echo $dataset?>">
                            <div class="card-img">
                                <img src="<?php echo $card_img['url'] ?>" alt="<?php echo $card_img['alt'] ?>">
                            </div>
                            <div class="card-title">
                                <p><?php echo $card_title ?></p>
                            </div>
                        </article>
    
                        <?php endwhile;?>
                    <?php endif;?>
                </div>

            </div>
        </section>

        <section class="top-casinos main-bg">
            <div class="container">
                <div class="top-casinos-info">
                    <h2>Our top casinos</h2>
                    <div class="tick-to-compare">
                            <div class="tick-svg">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="#2ECC71" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6.00011 13.6134L1.86011 9.47336L3.74677 7.58669L6.00011 9.84669L12.5868 3.25336L14.4734 5.14002L6.00011 13.6134Z" fill="white"/>
                                </svg>
                            </div>
                            <div class="tick-text">
                                Tick to compare two or more Casinos
                            </div>
                    </div>
                </div>
                <div class="lds-ring">
                            <div>

                            </div>
                            <div>

                            </div>
                            <div>

                            </div>
                            <div>
                                
                            </div>
                        </div>
                <div class="top-casinos-list">
                    <?php 
                        $loop = new WP_Query(array(
                            'post_type' => 'casino',
                            'posts_per_page' => -1,
                            'meta_key' => 'casino_rating',
                            'orderby' => 'meta_value_num',
                            'order' => 'DESC'
                        ))
                    ?>
                    <?php if($loop -> have_posts() ) :?>
                        <!-- CARD -->
                        <?php $id = 1?>
                        <?php while ($loop->have_posts()): $loop->the_post();?>
                        
                        <?php $id++ ;
                        
                        $name = "cb" . $id;

                        $tag_id = "cb" . $id;

                        $label_for = "cb" . $id;

                        ?>
                        
                        
                        <div class="casino-card" data-spins="<?php echo get_field('free_spins')?>" data-cash="<?php echo get_field('bonus_cash')?>" data-percent="<?php echo get_field('bonus_percent')?>" data-id="<?php echo get_the_id();?>">
                        
                            <div class="top">
                                
                                    <div class="first-sec">
                                        
                                        <div class="cc-checkbox">
                                            <input type="checkbox" name="<?php echo $name?>" id="<?php echo $tag_id ?>">

                                            <label class="custom-checkbox" for="<?php echo $label_for ?>">
                                                <svg class="box" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24" height="24" fill="white"/>
                                                    <g id="Property 1=Default" clip-path="url(#clip0_14_2685)">
                                                    <rect class="box" x="1" y="1" width="22" height="22" rx="3" stroke="#2ECC71" stroke-width="2"/>
                                                    </g>
                                                    <g id="check-bold">   
                                                    <path transform="translate(4, 4)" id="Vector" d="M6.00011 13.6133L1.86011 9.47333L3.74677 7.58667L6.00011 9.84667L12.5868 3.25333L14.4734 5.14L6.00011 13.6133Z" fill="white"/>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_14_2685">
                                                        <rect width="24" height="24" fill="#white"/>
                                                    </clipPath>
                                                    </defs>
                                                </svg>
                                            </label>
                                        </div>


                                        
                                        <div class="card-img">
                                        <?php 
                                            $card_img = get_field('casino_img');
                                            
                                        ?>
                                            <img src="<?php echo $card_img['url'] ?>" alt="<?php echo $card_img['alt'] ?>">
                                        </div>
    
                                        <div>
                                            <div class="card-title">
                                                <p>
                                                   <a href="<?php the_permalink(); ?>"><?php the_field('casino_name') ?></a>
                                                </p>
                                            </div>
            
                                            <div class="card-bonus">
                                                <?php
                                                    $bonus_percent = get_field('bonus_percent');
                                                    $bonus_cash = get_field('bonus_cash');
                                                    $bonus_spins = get_field('free_spins')
                                                ?>
                                                <span>
                                                    <?php echo $bonus_percent ?>% Bonus up to &euro;<?php echo $bonus_cash ?>
                                                </span>
                                                <span>
                                                    + <?php echo $bonus_spins ?> Free Spins
                                                </span>
                                            </div>
    
                                        </div>

                                    </div>
    
    
                                    <div class="rating-percent">

                                        <div class="single-chart">
                                            <?php 
                                                $casino_rating = get_field('casino_rating');
                                                $stroke_color;
                                                if($casino_rating < 75){
                                                    $stroke_color = '#FFC215';
                                                }else {
                                                    $stroke_color = '#2ECC71';
                                                } 
                                            ?>
                                            <svg viewBox="0 0 36 36" class="circular-chart orange">
                                            <path class="circle-bg" style="stroke: <?php echo $stroke_color ?>"
                                                d="M18 2.0845
                                                a 15.9155 15.9155 0 0 1 0 31.831
                                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                            />
                                            <path class="circle"
                                            style="stroke: <?php echo $stroke_color ?>"    
                                            stroke-dasharray="<?php the_field('casino_rating') ?>, 100"
                                                d="M18 2.0845
                                                a 15.9155 15.9155 0 0 1 0 31.831
                                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                            />
                                            </svg>
                                        </div>
                                        
                                        <div class="rating-num"><?php the_field('casino_rating')?></div>
                                        Rating
                                    
                                    </div>

                                    <div class="cf-div">  
                                        <div class="casino-features">
                                            <?php if(have_rows('casino_features') ) :?>
                                                <?php 
                                                    while( have_rows('casino_features') ) : the_row();   
                                                    $row_text = get_sub_field('feature_text');
                                                    $row_img = get_sub_field('feature_img');
                                                ?>
                                                <div class="casino-features-item">
    
                                                    <img src="<?php echo $row_img['url'] ?>" alt="<?php $row_img['alt'] ?>">
                                                    
                                                    <span>
                                                        <?php echo $row_text ?>
                                                    </span>
                                                    
                                                </div>
                                                <?php  $id++ ?>
                                                <?php endwhile; ?>
                                            <?php endif;?>
                                        </div>
                                    </div>
                                    
                                    <div class="card-links">
                                        <button class="bonus-btn">
                                            GET BONUS
                                        </button>
                                        <div class="website-link">
                                                <?php $website_link = get_field('casino_website') ?>
                                                <a href="<?php if($website_link) echo $website_link['url'] ?>" target='_blank' class="aStyle">Go to website</a>
                                        </div>
                                    </div>
                                

                            </div>
                            <div class="bottom casino-review">
                                <div class="review-top">
                                    <span>Review</span>
                                    <span class="review-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M7.41 8.58002L12 13.17L16.59 8.58002L18 10L12 16L6 10L7.41 8.58002Z" fill="#113454"/>
                                    </svg></span>
                                </div>
                                <div class="review-content">
                                    <?php the_field('casino_review'); ?>
                                </div>
                                
                            </div>
                        </div>
                        
                        <?php endwhile; ?>
                        <!-- CARD END -->
                        
                    <?php endif; ?>
    
                </div>
                
                <div class="show-more-div">
                    <button class="show-more-btn">Show all</button>
                </div>
                

            </div>

        </section>

        <section class="slot-front-section">
            <div class="popular-slots">
                <div class="container">
                    <div class="slot-section-titles">
                        <h3>Popular slots</h3>
                        <a href="<?php echo get_permalink(122)?>">ALL SLOTS &raquo;</a>
                    </div>
                    <div class="slot-section-cards slot-cards">
                        <?php 
                         get_template_part('template-parts/slot','cards')
                        ?>
                    </div>
                </div>
            </div>
            <div class="new-slots main-bg">
                <div class="container">
                    <div class="slot-section-titles">
                        <h3>New slots</h3>
                        <a href="<?php echo get_permalink(122)?>">ALL SLOTS &raquo;</a>
                    </div>
                    <div class="slot-section-cards slot-cards">
                        <?php 
                            get_template_part('template-parts/slot','cards')
                        ?>
                    </div>
                </div>
            </div>


        </section>

        <section class="front-page-content">
            <div class="container"> 
                <?php
                    if (have_posts()) :
                        while (have_posts()) :
                            the_post();
                            the_content();
                        endwhile;
                    endif;
                ?>
            </div>
        </section>
    </main>
    
    
    <?php 

get_footer();

?>