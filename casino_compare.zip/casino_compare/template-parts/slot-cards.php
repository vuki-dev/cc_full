<?php
                            $loop_slots = new WP_Query(array(
                                'post_type' => 'slots',
                                'posts_per_page' => 4,
                            ))
                        ?>
                        <?php
                        if($loop_slots->have_posts()) : 
                    ?>
                        <?php while($loop_slots->have_posts()) : $loop_slots->the_post();?>
                        <?php
                            $slot_type = get_field("slot_type");
                            $slot_img = get_field("slot_img");
                            $casino_provider = get_field("casino_provider");
                            $slot_date = get_field("date");
                            $rtp = get_field("rtp_percent");
                            $jackpot_type = get_field("jackpot_type");
                            $slot_feat = get_field("features");
                            $slot_volat = get_field("volatility");
                            $buy_bonus = get_field("buy_bonus");
                            $link = get_field("slots_link");
                        ?>  
                        <article class="single-slot" <?php if($buy_bonus) echo "data-bonus='true'"?>>
                            <div class="slot-front-side">
                                <img src="<?php echo $slot_img["url"]?>" alt="<?php echo $slot_img["alt"]?>" class="slot-img">
                                <h3 class="slot-title"><?php echo the_title();?></h3>
                                <span class="slot-provider"><?php echo $casino_provider ?></span>
                                <button class="slot-play-btn bonus-btn">PLAY NOW</button>
                                <span class="more-info">
                                    More info <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                    <path d="M9.16699 8.00002H10.8337V6.33335H9.16699V8.00002ZM10.0003 17.1667C6.32533 17.1667 3.33366 14.175 3.33366 10.5C3.33366 6.82502 6.32533 3.83335 10.0003 3.83335C13.6753 3.83335 16.667 6.82502 16.667 10.5C16.667 14.175 13.6753 17.1667 10.0003 17.1667ZM10.0003 2.16669C8.90598 2.16669 7.82234 2.38224 6.8113 2.80102C5.80025 3.21981 4.88159 3.83364 4.10777 4.60746C2.54497 6.17027 1.66699 8.28988 1.66699 10.5C1.66699 12.7102 2.54497 14.8298 4.10777 16.3926C4.88159 17.1664 5.80025 17.7802 6.8113 18.199C7.82234 18.6178 8.90598 18.8334 10.0003 18.8334C12.2105 18.8334 14.3301 17.9554 15.8929 16.3926C17.4557 14.8298 18.3337 12.7102 18.3337 10.5C18.3337 9.40567 18.1181 8.32204 17.6993 7.31099C17.2805 6.29994 16.6667 5.38129 15.8929 4.60746C15.1191 3.83364 14.2004 3.21981 13.1894 2.80102C12.1783 2.38224 11.0947 2.16669 10.0003 2.16669ZM9.16699 14.6667H10.8337V9.66669H9.16699V14.6667Z" fill="#707487"/>
                                    </svg>
                                </span>
                            </div>
                            <div class="slot-back-side">
                                <h3><?php echo the_title();?></h3>
                                <div class="card-info">
                                    <div class="card-info-left">
                                        <div class="card-spans-div">
                                            <div>
                                                <span class="card-info-span1">
                                                    Type
                                                </span>
                                                <span class="card-info-span2">
                                                    <?php echo $slot_type;?>
                                                </span>
                                            </div>
                                                
                                            <div>
                                                <span class="card-info-span1">
                                                    Released
                                                </span>
                                                <span class="card-info-span2">
                                                    <?php echo $slot_date;?>
                                                </span>
                                            </div>
                                                
                                            <div>
                                                <span class="card-info-span1">
                                                    RTP
                                                </span>
                                                <span class="card-info-span2" id="rtp">
                                                    <?php echo $rtp;?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="card-info-right">
                                        <div class="card-spans-div">
                                            <div>
                                                <span class="card-info-span1">
                                                    Jackpot
                                                </span>
                                                <span class="card-info-span2" id="jackpot-type">
                                                    <?php echo $jackpot_type;?>
                                                </span>
                                            </div>
                                                
                                            <div>
                                                <span class="card-info-span1">
                                                    Features
                                                </span>
                                                <span class="card-info-span2">
                                                    <?php echo $slot_feat;?>
                                                </span>
                                            </div>
                                                
                                            <div>
                                                <span class="card-info-span1">
                                                    Volatility
                                                </span>
                                                <span class="card-info-span2">
                                                    <?php echo $slot_volat;?>
                                                </span>
                                            </div>
                                                
                                        </div>
                                    </div>
                                </div>
                                    <button class="slot-play-btn bonus-btn">PLAY NOW</button>
    
                                    <span class="card-back">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 17 17" fill="none">
                                        <path d="M12.8417 13.9026L9.02508 10.0859L12.8417 6.26094L11.6667 5.08594L6.66675 10.0859L11.6667 15.0859L12.8417 13.9026Z" fill="#707487"/>
                                        </svg>
                                        Back
                                    </span>
                            
    
    
                            </div>
    
                        </article>
                            
    
                        <?php endwhile; ?>
                    <?php
                        endif;
                    ?>