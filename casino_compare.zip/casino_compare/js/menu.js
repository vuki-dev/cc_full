document.addEventListener('DOMContentLoaded', function()
{
    let searchBar = document.getElementById('search-bar');
    let navigation = document.getElementById('site-navigation2');
    let menuBtn = document.getElementById('menu-button');
    let menuBtnImg = document.getElementById('menu-btn-img');

    let clicked = false;

    menuBtn.addEventListener('click', function(){
        

        if(clicked === false){
            navigation.classList.add('menu-open');
            searchBar.classList.add('search-open');
    
            menuBtnImg.src = "http://localhost/casino_compare/wp-content/uploads/2023/07/icons8-close.svg";

            clicked = true;

        } else {
            navigation.classList.remove('menu-open');
            searchBar.classList.remove('search-open');

            menuBtnImg.src = "http://localhost/casino_compare/wp-content/uploads/2023/07/icons8-menu.svg"
            
            clicked = false;
        }

    });
}
)
