function onlySlotPageScript() {
    let slotsList = document.querySelector('.slot-cards').children
    
    let slotsCategories = document.querySelector('.slots-categories').children;
    
    function emptyHTMLCollection(collection) {
        while (collection.length > 0) {
          collection[0].parentNode.removeChild(collection[0]);
        }
    }
    
    let arrSlots = Array.from(slotsList)
    let originalArr = Array.from(slotsList);
    
    let selected = slotsCategories[0];
    
    function checkSelected(){
        for(let i=0; i<slotsCategories.length; i++){
            if(selected === slotsCategories[i]){
                slotsCategories[i].style.backgroundColor = '#113454'
                slotsCategories[i].style.color = '#FFFFFF'         
            }
            else{       
                slotsCategories[i].style.color = '#113454'
                slotsCategories[i].style.backgroundColor = '#FFFFFF'  
            }
        }
    }
    checkSelected();
    
    
    for(let i=0; i< slotsCategories.length; i++){
        let category = slotsCategories[i];
    
        category.addEventListener('click',function(){
            if(category.dataset.info === 'all-slots'){
                selected = category;
                checkSelected();
                emptyHTMLCollection(slotsList)
    
                for(let i=0; i<originalArr.length; i++){
                    document.querySelector('.slot-cards').appendChild(originalArr[i]);
                }
            };
            if(category.dataset.info === 'best-payout'){
                selected = category;
                checkSelected();
                emptyHTMLCollection(slotsList)
                
                arrSlots.sort( (a,b) => parseFloat(b.querySelector('#rtp').textContent) - parseFloat(a.querySelector('#rtp').textContent) )
    
                for(let i=0; i<arrSlots.length; i++){
                    document.querySelector('.slot-cards').appendChild(arrSlots[i]);
                }
            };
            if(category.dataset.info === 'bonus-buy'){
                selected = category;
                checkSelected();
                emptyHTMLCollection(slotsList)
    
                for(let i=0; i<arrSlots.length; i++){
                    if(arrSlots[i].dataset.bonus === 'true'){
                        document.querySelector('.slot-cards').appendChild(arrSlots[i]);
                    }
                }
            };
            if(category.dataset.info === 'progressive-slots'){
                selected = category;
                checkSelected();
                emptyHTMLCollection(slotsList);
    
                for(let i=0; i<arrSlots.length; i++){
                    if(arrSlots[i].querySelector('#jackpot-type').textContent.trim().toLowerCase() === 'progressive'){
                        document.querySelector('.slot-cards').appendChild(arrSlots[i]);
                    }
                }
            }
    
        })
    
    
      } 

}

onlySlotPageScript();