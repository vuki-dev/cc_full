// review expand script

const initScript2 = function(){
    let casinosList = document.querySelector('.top-casinos-list');

    
    let resizeTimeout;
    let originalHeight = casinosList.scrollHeight;
    
    // Function to update the container height
    function updateContainerHeight() {
        let sumHeight = 0;
        const gap = 30;
        let gapSum = 0;
        let nOfBlockCards = 0;

        casinoSlots = document.querySelectorAll('.casino-card');

        casinoSlots.forEach(function(slot){
            let computedDisplay = getComputedStyle(slot);

            if(computedDisplay.getPropertyValue('display') === 'block'){
                nOfBlockCards++
            }
        })


        casinoSlots.forEach(function(slot){
            const computedStyle = window.getComputedStyle(slot);
            const height = parseFloat(computedStyle.getPropertyValue('height'));

            if(isNaN(height)){
                return;
            }
            else{
                let parentFlexWrap = window.getComputedStyle(document.querySelector('.top-casinos-list'));
                console.log()
                let parentFlexWrapVal = parentFlexWrap.getPropertyValue('flex-wrap');
                if(parentFlexWrapVal === 'wrap'){
                    console.log('wrap')
                    sumHeight = Math.ceil(nOfBlockCards/2) * height;
                    gapSum += gap;
                
                } else {
                    sumHeight += height;
                    gapSum += gap;
                }
            }
        })
        gapSum -= 30;
        sumHeight += gapSum

        casinosList.style.height = sumHeight + 20 +'px'
    }

    // Call the updateContainerHeight function initially
    updateContainerHeight();

    // Add a resize event listener to handle window resizing
    window.addEventListener('resize', () => {
        // Clear any previous resize timeouts
        clearTimeout(resizeTimeout);

        // Set a new timeout to update the container height after a short delay
        resizeTimeout = setTimeout(() => {
            updateContainerHeight();
        }, 200); // Adjust the delay as needed
    });


   // console.log('script1 load')
    
    for(let i=0; i < casinosList.children.length; i++){
        let casinoCard = casinosList.children[i];
        
        let reviewBar = casinoCard.querySelector('.casino-review');
        let reviewContent = casinoCard.querySelector('.review-content')
        
        let isAnimating = false;
    
        let clicked = false;
    
        reviewBar.addEventListener('click',(e)=>{
            if(isAnimating){
                return;
            }
    
            isAnimating = true;
    
        
            
            let reviewIcon = reviewBar.querySelector('.review-icon')
    
            if(clicked){
                casinosList.style.height = casinosList.scrollHeight - reviewContent.scrollHeight + 'px'
                // explanation bottom
                
                reviewBar.style.height = '48px'
    
    
                clicked = false;
                
                reviewIcon.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M7.41 8.58002L12 13.17L16.59 8.58002L18 10L12 16L6 10L7.41 8.58002Z" fill="#113454"/>
                </svg>
                `
    
                setTimeout(() => {
                    isAnimating = false;
                }, 300);
    
                return;
            }
    
            
            reviewIcon.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M7.41 15.42L12 10.83L16.59 15.42L18 14L12 8.00004L6 14L7.41 15.42Z" fill="#113454"/>
            </svg>
            `
            reviewBar.style.height = reviewBar.scrollHeight + 'px';
    
            casinosList.style.height = casinosList.scrollHeight + reviewContent.scrollHeight +'px'
            // explanation bottom
            
            clicked = true;
    
            setTimeout(() => {
                isAnimating = false;
            }, 300);
    
        })
    
    }
    
    // review expand script end;
    
    // checkbox scripts 
    
    
    
    
    for(let i=0; i < casinosList.children.length; i++){
        let casinoCard = casinosList.children[i];
        
        let checkbox = casinoCard.querySelector('.cc-checkbox');
        
    
        let singleCheckbox = checkbox.children[0]
    
    
        singleCheckbox.addEventListener('click',()=>{
            if(singleCheckbox.checked){
                
                if(compareArr.length === 4){
                    return;
                    // linked to comparisonScript.js ~~~~~~ disables checking animation
                }
    
                casinoCard.style.border = '2px solid #2ECC71'
                
            } else{
                casinoCard.style.border = 'none'
            }
    
        })
    
    }
    
    // list more script
    
    let showMoreBtn = document.querySelector('.show-more-btn')
    
    
    casinosList.style.height = casinosList.scrollHeight + 20 + 'px';
    // for animation 
    
    
    showMoreBtn.addEventListener('click',() => {
        for(let i=0; i < casinosList.children.length; i++){
            let casinoCard = casinosList.children[i];
            casinoCard.style.display= 'block'
        }
        
        casinosList.style.height = casinosList.scrollHeight + 30 + 'px'; // for animation
    
        showMoreBtn.style.display = 'none'
        
    })
      
    
    /* 
    EXPLANATION
    casinosList.style.height = casinosList.scrollHeight + reviewContent.scrollHeight + 'px'
    
    Since height needs exact value to be animated, parent div has fixed height ( because of show more button expand animation ).When review div is clicked overflow:hidden hides review content. So adding and removing review content scrollHeight to parent div fixes the problem.
    */ 
}

initScript2();


// sorting selection script

function initScript3(){

    let casinosList = document.querySelector('.top-casinos-list');

    let categories = document.querySelector('.categories .cards').children;
    
    let selectedCategory = categories[0];
    
    function checkSelectedCat(){
        for(let i=0; i<categories.length; i++){
            if(categories[i] === selectedCategory){
                categories[i].style.backgroundColor = '#113454'
                categories[i].style.color = '#fff'
            }
            else{
                categories[i].style.backgroundColor = '#fff'
                categories[i].style.color = '#113454'
            }
        }
    }
    
    checkSelectedCat();
    
    
    
    let scc = casinosList.children; //scc 
    
    function emptyHTMLCollection(collection) {
        while (collection.length > 0) {
          collection[0].parentNode.removeChild(collection[0]);
        }
      }
    
    for(let i=0; i<categories.length; i++){
    
        categories[i].addEventListener('click',function(){
            selectedCategory = categories[i];
            checkSelectedCat();
            
            let sortedArr = [];
    
            if(categories[i].dataset.inf === 'popular'){
                document.querySelector('.top-casinos-info h2').textContent = 'Our top casinos'
    
    
                sortedArr = Array.from(scc).sort( (a,b)=> parseInt(b.querySelector('.rating-num').textContent) - parseInt(a.querySelector('.rating-num').textContent) )

              //  console.log(sortedArr.querySelector('.top .rating-percent.rating-num'))
                
                emptyHTMLCollection(scc);
    
                for(let i=0; i<sortedArr.length; i++){
                    casinosList.appendChild(sortedArr[i]);
                } 
    
            };
            if(categories[i].dataset.inf === 'bonus'){
                document.querySelector('.top-casinos-info h2').textContent = 'Highest bonus percentage'
    
                sortedArr = Array.from(scc).sort( (a,b)=> parseInt(b.dataset.percent) - parseInt(a.dataset.percent) )
                
                emptyHTMLCollection(scc);
    
                for(let i=0; i<sortedArr.length; i++){
                    casinosList.appendChild(sortedArr[i]);
                } 
    
            };
            if(categories[i].dataset.inf === 'free-spins'){
                document.querySelector('.top-casinos-info h2').textContent = 'Most free spins'
    
                sortedArr = Array.from(scc).sort( (a,b)=> parseInt(b.dataset.spins) - parseInt(a.dataset.spins) );
    
                emptyHTMLCollection(scc);
    
                for(let i=0; i<sortedArr.length; i++){
                    casinosList.appendChild(sortedArr[i]);
                } 
            };
            if(categories[i].dataset.inf === 'newest'){
                document.querySelector('.top-casinos-info h2').textContent = 'Newest casinos'
    
                sortedArr = Array.from(scc).sort( (a,b)=> parseInt(b.dataset.id) - parseInt(a.dataset.id) );
    
                emptyHTMLCollection(scc);
    
                for(let i=0; i<sortedArr.length; i++){
                    casinosList.appendChild(sortedArr[i]);
                } 
            };
            if(categories[i].dataset.inf === 'payout'){
                document.querySelector('.top-casinos-info h2').textContent = 'Greatest cash payout'
    
                sortedArr = Array.from(scc).sort( (a,b)=> parseInt(b.dataset.cash) - parseInt(a.dataset.cash) );
    
                emptyHTMLCollection(scc);
    
                for(let i=0; i<sortedArr.length; i++){
                    casinosList.appendChild(sortedArr[i]);
                } 
            };
    
            //console.log(originalContent)
            
            
        })
    }
}

initScript3();
