let stickyCompareDiv = document.querySelector('.compare-sticky-div');

let allCasinos = [];
let compareArr = [];

let originalContent;


async function fetchCasinoPosts() {
    let casinosList = document.querySelector('.top-casinos-list')
    try {
        const res = await axios.get('http://localhost/casino_compare/wp-json/wp/v2/casino');

        for (let i = 0; i < res.data.length; i++) {
            const casino = res.data[i].acf;
    
            const apiImgUrl = `http://localhost/casino_compare/wp-json/wp/v2/media/${casino.casino_img}`;
          //  console.log(apiImgUrl);

            try {
                const imgUrlResponse = await axios.get(apiImgUrl);
                const imgUrl = imgUrlResponse.data.source_url;

                allCasinos.push({
                    casinoId: res.data[i].id,
                    casinoBonusCash: casino.bonus_cash,
                    casinoSpins: casino.free_spins,
                    casinoBonusPercent: casino.bonus_percent,
                    casinoName: casino.casino_name,
                    casinoRating: casino.casino_rating,
                    casinoImgSrc: imgUrl,
                    casinoBonusAmount: `${casino.bonus_percent} up to €${casino.bonus_cash} + ${casino.free_spins} Free spins`,
                    casinoPros: casino.pros,
                    casinoCons: casino.cons,
                    casinoSoftwareProviders: casino.software_providers,
                    casinoPaymentMethods: casino.payment_methods,
                });

            } catch (error) {
                console.error("Error fetching casino image:", error);
            }
        }
        
        document.querySelector('.lds-ring').style.display = 'none'
        casinosList.style.opacity = 1;
        originalContent = document.querySelector('main').innerHTML;

    } catch (error) {
        console.error("Error fetching casino data:", error);
    }
}

fetchCasinoPosts();


const initializeScript = () => {
    



    let casinosList = document.querySelector('.top-casinos-list')
        // COMPARISON IMPORTANT SCRIPTS START 
    
    
        let slotsList = document.querySelector('.sticky-slots');
    
        function clearStickySlots(){
            for(let j=0; j<slotsList.children.length; j++){
                let singleSlot = slotsList.children[j];
                singleSlot.setAttribute('data-casino', '');     
                singleSlot.querySelector('.slot-img img').alt = ''
                singleSlot.querySelector('.slot-img img').src = ''
            }
        }
    
    
        function removeItem(cardTitle){
            for(let i=0; i<compareArr.length; i++){
                if(cardTitle === compareArr[i].casinoName){
                    
                    for(let j=0; j<slotsList.children.length; j++){
                        let singleSlot = slotsList.children[j];
                        
                        if(singleSlot.getAttribute('data-casino') === compareArr[i].casinoName){
                            
                            singleSlot.setAttribute('data-casino', '');     
                            singleSlot.querySelector('.slot-img img').alt = ''
                            singleSlot.querySelector('.slot-img img').src = ''
            
                            break;
                        }
                    }
    
                    compareArr.splice(compareArr.indexOf(compareArr[i]),1)
                    
                }
            }
        }
    
        function checkStickyDiv(){
    
            
            if(compareArr.length > 0){
                if(document.body.clientWidth > 910){
                    
                    stickyCompareDiv.style.display = 'flex'
                    stickyCompareDiv.style.alignItems = 'center'
    
                    stickyCompareDiv.children[0].style.display = 'flex'
                    stickyCompareDiv.children[0].style.justifyContent = 'space-between'
    
    
                    return
                }
                stickyCompareDiv.style.display = 'block'
            } else{
                stickyCompareDiv.style.display = 'none'
            }
        }
    
    
        function stickyChangeNumber(){
            document.querySelector('.sticky-title-span').textContent = compareArr.length + ' of 4 Casino selected'
        }
    
    
    
        function checkCompareBtn(){
            if(compareArr.length <= 1){
                document.querySelector('.compare-btn').disabled = true;
                document.querySelector('.compare-btn').style.opacity = '50%';
            } else{
                document.querySelector('.compare-btn').disabled = false;
                document.querySelector('.compare-btn').style.opacity = 1;
    
            }
        }
    
    
        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // CHECKBOX EVENTS !!! ~adding to comparison
        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        for(let i=0; i < casinosList.children.length; i++){
            let casinoCard = casinosList.children[i];
    
            let checkbox = casinoCard.querySelector('.cc-checkbox input[type=checkbox]')
            let cardTitle = casinoCard.querySelector('.card-title p').textContent.trim()
            
            checkbox.addEventListener('click', function(){
            // checkStickyDiv()
    
                if(compareArr.length === 4){
                    // in card-scripts.js disable checking animation
                    checkbox.checked = false;      
                    removeItem(cardTitle);
                    stickyChangeNumber()
            
                    return;
                } else {};
    
                if(checkbox.checked === true){
                    for(let i=0; i<allCasinos.length; i++){
                        if(allCasinos[i].casinoName === cardTitle){
                            compareArr.push(allCasinos[i])
    
                            //adding to sticky div
                            let slotsList = document.querySelector('.sticky-slots');
                            for(let j=0; j<slotsList.children.length; j++){
                                let singleSlot = slotsList.children[j];
                                
                                if(singleSlot.querySelector('.slot-img img').src === 'http://localhost/casino_compare/'){
                                    
                                    singleSlot.querySelector('.slot-img img').src = allCasinos[i].casinoImgSrc;
                                    singleSlot.querySelector('.slot-img img').alt = 'Casino image'
                                    singleSlot.dataset.casino = allCasinos[i].casinoName;
                                    break;
                                }
                            }
    
                            checkCompareBtn();
                            stickyChangeNumber();
                            checkStickyDiv();
                            return;
                        }
                    }
                
                } else{
                    removeItem(cardTitle)
    
                    checkCompareBtn();
                    stickyChangeNumber();
                }
    
                checkStickyDiv()
            })
    
        }
    
    
    
    
        let compareBtn = document.querySelector('.compare-btn');
    
        function createLayout(){
            let containerDiv = document.createElement('div')
            containerDiv.className = 'container'
    
            let wrapper = document.createElement('div');
            wrapper.className = 'assistant-wrapper'
    
            let backLink = document.createElement('div');
            backLink.className = 'backlink';
            backLink.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
            <path d="M12.8415 13.9026L9.02484 10.0859L12.8415 6.26094L11.6665 5.08594L6.6665 10.0859L11.6665 15.0859L12.8415 13.9026Z" fill="#707487"/>
            </svg> <p>Return to homepage</p>`
            backLink.style.display = 'flex';
            backLink.style.alignItems = 'center'
            backLink.addEventListener('click',()=>{
                document.querySelector('main').classList.remove('container')
                document.querySelector('main').innerHTML = originalContent;
                compareArr = [];
                clearStickySlots();
                initScript2();
                initializeScript();
                initScript3();
                initSlotScripts();
            })
            
            let header = document.createElement('h2');
            header.className = 'assistant-title';
            header.textContent = 'Comparision Assistant'
    
            let assistant = document.createElement('table');
            let borderDiv = document.createElement('div');
            borderDiv.className = 'border-div'
            borderDiv.appendChild(assistant)
    
            // assistant children;
    
            let tbody = document.createElement('tbody');
            assistant.appendChild(tbody);
    
            let nOfRows = 6;
            for(let i=0; i<nOfRows; i++){
                let tr = document.createElement('tr');
                tr.className = 'tr'+i;
                
                for( let j=1; j<6; j++){
                    let td = document.createElement('td');
                    td.className = 'td'+j;
    
                    if(i === 0 && j>1){
                        let trdiv1 = document.createElement('div');
                        let trdiv2 = document.createElement('div');
                        let trdiv3 = document.createElement('div');
                        let trdiv4 = document.createElement('div')
                        trdiv4.className = 'mini-hero'
    
                        let tr0img = document.createElement('img');
                        let tr0title = document.createElement('span');
                        tr0title.className = 'span-title'
                        let tr0rating = document.createElement('p');
                        tr0rating.className = 'p-rating'
                        let tr0x = document.createElement('span');
                        tr0x.className = 'spanX'
    
                        trdiv1.appendChild(tr0img);
                        trdiv2.appendChild(tr0title);
                        trdiv2.appendChild(tr0rating);
                        trdiv3.appendChild(tr0x);
    
                        trdiv4.appendChild(trdiv1)
                        trdiv4.appendChild(trdiv2)
                        trdiv4.appendChild(trdiv3)
    
                        td.appendChild(trdiv4)
                    }
    
                    tr.appendChild(td)
                }
    
                tbody.appendChild(tr)
            }
            // assistant end//
    
            
        
    
            containerDiv.appendChild(backLink);
            containerDiv.appendChild(header);
            containerDiv.appendChild(borderDiv);
            
            wrapper.appendChild(containerDiv)
    
            document.querySelector('main').innerHTML = '';
            document.querySelector('main').appendChild(wrapper)
            stickyCompareDiv.style.display = 'none'
    
            return wrapper;
        }
    
    
    
        compareBtn.addEventListener('click',function(e){
            if(compareArr.length <= 1){
                return;
            }
            
            let layout = createLayout();
            
            layout.querySelector('.tr0 .td1').textContent = 'Casinos name';
            layout.querySelector('.tr1 .td1').textContent = 'Casino bonus amount';
            layout.querySelector('.tr2 .td1').textContent = 'Pros';
            layout.querySelector('.tr3 .td1').textContent = 'Cons';
            layout.querySelector('.tr4 .td1').textContent = 'Software providers';
            layout.querySelector('.tr5 .td1').textContent = 'Payment methods';

            let count = 2; //starts from td2
            for(let i=0; i<compareArr.length; i++){
                //layout.querySelector('.tr')
                
                
                layout.querySelector('.tr0 .td'+count+' div img').style.width = '100px';
                layout.querySelector('.tr0 .td'+count+' div img').style.height = '100px';
                layout.querySelector('.tr0 .td'+count+' div img').src = compareArr[i].casinoImgSrc;
                layout.querySelector('.tr0 .td'+count+' div .span-title').innerHTML = compareArr[i].casinoName;
                layout.querySelector('.tr0 .td'+count+' div .p-rating').innerHTML ='Rating: '+ '<span class="span-rating">'+compareArr[i].casinoRating+'</span>';
                
                let spanRating = layout.querySelector('.tr0 .td'+count+' div .p-rating .span-rating');
                if(parseInt(spanRating.textContent)>=75){
                    spanRating.style.color = '#2ECC71'
                }else{
                    spanRating.style.color = '#FFC215'
                };
    
    
                layout.querySelector('.tr1 .td'+count).innerHTML = '<p>'+compareArr[i].casinoBonusAmount+'</p>';
    
                layout.querySelector('.tr2 .td'+count).innerHTML = '<p>'+ compareArr[i].casinoPros+'</p>';
    
                layout.querySelector('.tr3 .td'+count).innerHTML = '<p>'+ compareArr[i].casinoCons+'</p>';
    
                layout.querySelector('.tr4 .td'+count).innerHTML = '<p>'+ compareArr[i].casinoSoftwareProviders+'</p>';
    
                layout.querySelector('.tr5 .td'+count).innerHTML = '<p>'+ compareArr[i].casinoPaymentMethods+'</p>';
    
                count++;
                scrollTo({top: 100})
            }
            
        })

        let closeBtn = document.querySelector('.close-btn');

        closeBtn.addEventListener('click', function(){
            compareArr = [];
            clearStickySlots();
            checkCompareBtn();
            checkStickyDiv();

            for(let i=0; i < casinosList.children.length; i++){
                let casinoCard = casinosList.children[i];
                
                let checkbox = casinoCard.querySelector('.cc-checkbox');
                
            
                let singleCheckbox = checkbox.children[0]
            
                if(singleCheckbox.checked){
                    singleCheckbox.checked = false;
                    console.log(singleCheckbox.checked)
        
                    casinoCard.style.border = 'none'
                    
                } 
            
            }
        })

        
        
        
        function handleRemoveSlot(){
            let removeSlot = document.querySelectorAll('.compare-slot');
            
            removeSlot.forEach(function(slot){
                slot.querySelector('.remove-slot svg').addEventListener('click',function(){
                    let casinosList = document.querySelector('.top-casinos-list')
                    for(let i=0; i < casinosList.children.length; i++){
                        
                        let casinoCard = casinosList.children[i];
                        
                        let checkbox = casinoCard.querySelector('.cc-checkbox');
                        
                        let singleCheckbox = checkbox.children[0]
                        
                        
                        if(slot.dataset.casino === casinoCard.querySelector('.card-title').textContent.trim()){                
                            if(singleCheckbox.checked){
                                console.log(casinoCard)
                                console.log(checkbox)
                                singleCheckbox.checked = false;               
                                casinoCard.style.border = 'none'
                            } 
                        }
                        
                        
                    }
                    
                    removeItem(slot.dataset.casino);
                    checkStickyDiv();
                    stickyChangeNumber();
                    checkCompareBtn();
                    })
            })

        }
        handleRemoveSlot();
}

initializeScript();


