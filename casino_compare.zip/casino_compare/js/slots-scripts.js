let initSlotScripts = function(){

    let allSlotsLists = document.querySelectorAll('.slot-cards');

    allSlotsLists.forEach(function(slotList){

        let slotsList = slotList       
        
        for(let i=0; i<slotsList.children.length; i++){
            let singleSlot = slotsList.children[i]
                
            singleSlot.querySelector('.more-info').addEventListener('click',()=>{
                singleSlot.querySelector('.slot-back-side').style.display = 'flex';
                singleSlot.querySelector('.slot-front-side').style.opacity = '0';
            })
        
            singleSlot.querySelector('.card-back').addEventListener('click', function(){
                singleSlot.querySelector('.slot-back-side').style.display = 'none';
                singleSlot.querySelector('.slot-front-side').style.opacity = '1';
            }) 
        }
    
    })
    
}

initSlotScripts();