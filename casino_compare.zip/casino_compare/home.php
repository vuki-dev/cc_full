<?php

get_header();
?>
	<main class="main-bg">
		<div class="container">
			<div class="content blog-content">
			<?php
				if (have_posts()) :
					while (have_posts()) :
						the_post();
			?>

			<article class="single-blog-post">
				<h2 class="blog-post-title"><a href="<?php the_permalink();?>" class="blog-post-link"><?php the_title();?></a></h2>
				<p class="blog-post-excerpt"><?php the_excerpt();?></p>
				<hr>
			</article>


			<?php 
					endwhile;
				endif;
				
			?>
			
			</div>
		</div>
	</main>	

<?php 
get_footer();
?>