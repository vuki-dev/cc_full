<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package casino_compare
 */

get_header();
?>

	<main id="primary" class="site-main main-bg">
		<div class="container">
			<div class="post-content content">
				<h2 class="post-title"><?php the_title();?></h2>
				<hr>
				<div class="post-content">
					<?php the_content(); ?>
					
				</div>
			</div>
		</div>  <!-- container end -->
	</main><!-- #main -->

<?php 
get_footer();
?>